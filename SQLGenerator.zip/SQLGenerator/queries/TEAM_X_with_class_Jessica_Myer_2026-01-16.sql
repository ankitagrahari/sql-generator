----
----
----From: Myer, Jessica <Jessica.Myer@reliancematrix.com> 
----Sent: Friday, January 16, 2026 4:55 PM
----To: Graff, Lawrence <Lawrence.Graff@reliancematrix.com>
----Cc: McPhillips, Kevin <Kevin.McPhillips@reliancematrix.com>; Higgins, Sarah <Sarah.Higgins@reliancematrix.com>
----Subject: Team X
----
----Hi Lawrence, 
----
----Happy New Year!
----
----We are looking to see if you can pull us are report by TEAM X that would include classes for each policy by customer. 
----
----Could you pull a report like that and share with us?
----
----Thanks,


   SELECT DISTINCT 
   cu.fullname as customer_name,   
   POLICYNUMBER, C.CODE, PP.CLASS     -----, PP.POLICYPLANID, VOLUMECALCULATIONID, PC.POLICYCOVERAGEID
   , VC.VCTYPE, C.COVERAGENAME        ---      , P.POLICYID
   , PP.PLANTYPE, VC.PLANA, VC.PLANB, VC.PLANC
           , VC.EMPLOYERCONTRIBUTION, VC.EMPLOYEECONTRIBUTION
           , NVL(SUBSTR(MT.ITEM, 1, 9), '        ')  as TEAM
           , fo.location as RSO 
   FROM POLICY P
   INNER JOIN POLICYPLAN PP ON PP.POLICYID = P.POLICYID
   INNER JOIN VOLUMECALCULATION VC ON VC.POLICYPLANID = PP.POLICYPLANID
   INNER JOIN POLICYCOVERAGE PC ON PC.POLICYCOVERAGEID = PP.POLICYCOVERAGEID
   INNER JOIN COVERAGE C ON C.COVERAGEID = PC.COVERAGEID
   INNER JOIN FIELDOFFICE FO ON FO.FIELDOFFICEID = P.FIELDOFFICEID
   INNER JOIN CUSTOMER CU ON CU.CUSTOMERID = P.CUSTOMERID
   LEFT JOIN UDFIELD UDF ON UDF.ENTITYID = P.POLICYID 
                        AND UDF.ENTITYTYPEID = 200
   LEFT JOIN MTOPTION MT ON MT.OPTIONID = UDF.FIELD6 
   WHERE 1=1  --- PP.POLICYPLANID IN (SELECT POLICYPLANID FROM POLICYPLAN WHERE POLICYID IN (SELECT POLICYID FROM POLICY WHERE CUSTOMERID = 141129))
      AND PP.STATUSID = 192
      AND VC.STATUSID = 192
      AND P.STATUSID = 207
      AND PP.DELETEBY IS NULL
      AND VC.DELETEBY IS NULL
      AND MT.ITEM = 'TEAM X'  
      ORDER BY 1, 2, 3, 4;
      